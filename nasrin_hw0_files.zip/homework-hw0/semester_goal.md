# Data Mining Goals
* It helps me to ___detect risks and fraud___
* It helps me to ___understand behaviors, trends and discover hidden patterns___
* It helps me to ___analyses very large quantities of data___
